<?php
// cookies
    if (isset($_COOKIE['teste_cookie'])) {
        echo 'Cookie funcionando!';
    } else {
        echo 'Cookie vai ser criado.';
        setcookie('teste_cookie', 'Algum valor...', time() + 10);
    }


// sessão
    echo "<br>";
    session_start();

    if (isset($_SESSION['usuario'])) {
        echo "Bem vindo {$_SESSION['usuario']}!";
    } else {
        echo 'Você NUNCA passou por aqui.';
        $_SESSION['usuario'] = 'teste';
    }
?>