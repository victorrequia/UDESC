<?php
	date_default_timezone_set('America/Sao_Paulo');
	$dia = date('d/m/Y');
	$hora = date('H:i', time());
	print "Hoje é {$dia} e agora são {$hora}h";
?>


