<?php

// Funcao para somar valores
	function soma(){
		$p = func_get_args();
		$t = func_num_args();
		$s = 0;

		for ($i=0; $i<$t; $i++){
			$s += $p[$i];
		}

		return $s;
	}

	$r = soma(5,4,2);
	echo "A soma dos valores e $r";
	echo "<br>";

// Funcao prinft
	$produto = "cafe";
	$preco = 7.5;

	printf ("<br>O %s custa R$%.2f<br>", $produto, $preco); 
	
// Funcao print_r
	echo "<br>";
	$v2 = array (14,32,34,45);
	print_r($v2);
	echo "<br>";

// Funcao wordwrap
	$t = "<br>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid facilis nobis, voluptates tenetur molestiae mollitia cumque aliquam, eveniet dignissimos rem exercitationem fugit quas laudantium sequi nostrum quasi ex perspiciatis iure? Lorem, ipsum dolor sit amet consectetur adipisicing elit..";
	$r = wordwrap($t, 25, "</br>");
	echo $r;
	echo "<br>";

// Funcao strlen
	$txt = "Teste numero de letras";
	$tamanho = strlen($txt);
	echo "<br>$tamanho<br>";

// Funcao trim
	$txt = "Teste numero de letras";
	$palavras = str_word_count($txt);
	echo "<br>$palavras<br>";
?>


