<?php
	// Funcao para exibir numero de visitantes
	$arquivo = "visitantes.txt";

	$handle = fopen($arquivo, 'r+');

	$data = fread($handle, 512);

	$contador = $data + 1;

	echo "<br>Esta pagina foi visitada $contador vezes<br>";

	fseek($handle, 0);

	fwrite($handle, $contador);

	fclose($handle);
?>