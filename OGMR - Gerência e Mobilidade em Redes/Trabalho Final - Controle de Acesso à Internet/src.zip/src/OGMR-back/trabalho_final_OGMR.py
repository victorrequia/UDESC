from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
from pysnmp.hlapi import *
import logging
import threading
import time
from datetime import datetime, timezone

app = Flask(__name__)
CORS(app)
logging.basicConfig(level=logging.INFO)
DATABASE = 'mydatabase.db'

def get_db():
    db = sqlite3.connect(DATABASE)
    return db

def init_db():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS port_blocks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                port INTEGER NOT NULL,
                startDate TEXT NOT NULL,
                endDate TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS administradores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS salas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL UNIQUE,
                admin_id INTEGER,
                FOREIGN KEY (admin_id) REFERENCES administradores (id)
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS computadores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mac_address TEXT NOT NULL UNIQUE,
                port INTEGER NOT NULL,
                status TEXT NOT NULL,
                description TEXT,
                sala_id INTEGER,
                FOREIGN KEY (sala_id) REFERENCES salas (id)
            )
        ''')
        db.commit()
        cursor.close()

# listar os endereços MAC dos dispositivos conectados e o status das portas
def listar_mac_dispositivos(ip):
    result = []
    mac_port_map = {}

    lista = nextCmd(SnmpEngine(),
                    CommunityData('public'),
                    UdpTransportTarget((ip, 161)),
                    ContextData(),
                    ObjectType(ObjectIdentity('1.3.6.1.2.1.17.4.3.1.1')), 
                    ObjectType(ObjectIdentity('1.3.6.1.2.1.17.4.3.1.2')),  
                    lexicographicMode=False)

    for (errorIndication, errorStatus, errorIndex, varBinds) in lista:
        if errorIndication:
            print(errorIndication)
            break
        elif errorStatus:
            print('%s at %s' % (errorStatus.prettyPrint(),
                                errorIndex and varBinds[int(errorIndex) - 1][0] or '?'))
            break
        else:
            mac_address = ''.join(['%02x:' % b for b in varBinds[0][1].asNumbers()])[:-1]
            port = varBinds[1][1].prettyPrint()
            mac_port_map[port] = mac_address

    port_status_list = nextCmd(SnmpEngine(),
                               CommunityData('public'),
                               UdpTransportTarget((ip, 161)),
                               ContextData(),
                               ObjectType(ObjectIdentity('1.3.6.1.2.1.2.2.1.7')), 
                               ObjectType(ObjectIdentity('1.3.6.1.2.1.2.2.1.2')),  
                               lexicographicMode=False)

    for (errorIndication, errorStatus, errorIndex, varBinds) in port_status_list:
        if errorIndication:
            print(errorIndication)
            break
        elif errorStatus:
            print('%s at %s' % (errorStatus.prettyPrint(),
                                errorIndex and varBinds[int(errorIndex) - 1][0] or '?'))
            break
        else:
            port = varBinds[0][0].prettyPrint().split('.')[-1]
            status = 'up' if varBinds[0][1] == 1 else 'down'
            if_descr = varBinds[1][1].prettyPrint()
            mac_address = mac_port_map.get(port, 'None')

            db = get_db()
            cursor = db.cursor()
            cursor.execute('SELECT sala_id FROM computadores WHERE mac_address = ?', (mac_address,))
            existing_computer = cursor.fetchone()

            if existing_computer:
                sala_id = existing_computer[0]
                cursor.execute('''
                    UPDATE computadores
                    SET port = ?, status = ?, description = ?
                    WHERE mac_address = ?
                ''', (port, status, if_descr, mac_address))
            else:
                sala_id = None
                cursor.execute('''
                    INSERT OR REPLACE INTO computadores (mac_address, port, status, description, sala_id)
                    VALUES (?, ?, ?, ?, ?)
                ''', (mac_address, port, status, if_descr, sala_id))

            db.commit()
            cursor.close()

            result.append({'port': port, 'status': status, 'mac_address': mac_address, 'description': if_descr, 'sala_id': sala_id})

    return result

# rota para listar dispositivos conectados
@app.route('/api/computadores', methods=['GET'])
def computadores():
    ip = "10.90.90.90" 
    dispositivos = listar_mac_dispositivos(ip)

    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT computadores.id, computadores.mac_address, computadores.port, computadores.status, computadores.description, salas.nome
        FROM computadores
        LEFT JOIN salas ON computadores.sala_id = salas.id
    ''')
    computadores_com_salas = cursor.fetchall()
    cursor.close()

    result = []
    for dispositivo in dispositivos:
        for comp in computadores_com_salas:
            if dispositivo['mac_address'] == comp[1]:
                dispositivo['sala'] = comp[5]
                break
        else:
            dispositivo['sala'] = None
        result.append(dispositivo)

    return jsonify(result)

# Rota de login
@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            return jsonify({'success': False, 'error': 'Missing username or password'}), 400

        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
        user = cursor.fetchone()
        cursor.close()

        if user:
            return jsonify({'success': True}), 200
        else:
            return jsonify({'success': False}), 401

    except Exception as e:
        print(e)
        return jsonify({'success': False, 'error': 'Internal server error'}), 500
    
# Rota para criar usuário
@app.route('/api/user', methods=['POST'])
def create_user():
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            return jsonify({'success': False, 'error': 'Missing username or password'}), 400

        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        existing_user = cursor.fetchone()

        if existing_user:
            return jsonify({'success': False, 'error': 'User already exists'}), 400

        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
        db.commit()
        cursor.close()

        return jsonify({'success': True}), 200

    except Exception as e:
        print(e)
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

# Rota para listar administradores
@app.route('/api/administradores', methods=['GET'])
def listar_administradores():
    try:
        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT * FROM administradores')
        administradores = cursor.fetchall()
        cursor.close()

        result = [{'id': admin[0], 'username': admin[1]} for admin in administradores]
        return jsonify(result), 200

    except Exception as e:
        print(e)
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

# pegar a lista de admins
@app.route('/api/administradores', methods=['POST'])
def create_administrador():
    try:
        data = request.get_json()
        username = data.get('username')

        if not username:
            return jsonify({'success': False, 'error': 'Missing username'}), 400

        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT * FROM administradores WHERE username = ?', (username,))
        existing_admin = cursor.fetchone()

        if existing_admin:
            return jsonify({'success': False, 'error': 'Administrator already exists'}), 400

        cursor.execute('INSERT INTO administradores (username) VALUES (?)', (username,))
        db.commit()
        cursor.close()

        return jsonify({'success': True}), 200

    except Exception as e:
        print(e)
        return jsonify({'success': False, 'error': 'Internal server error'}), 500
    
# lista de salas
@app.route('/api/sala', methods=['POST'])
def create_sala():
    try:
        data = request.get_json()
        nome = data.get('nome')
        admin_id = data.get('admin_id')

        if not nome or not admin_id:
            return jsonify({'success': False, 'error': 'Missing nome or admin_id'}), 400

        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT * FROM administradores WHERE id = ?', (admin_id,))
        existing_admin = cursor.fetchone()

        if not existing_admin:
            return jsonify({'success': False, 'error': 'Admin not found'}), 404

        cursor.execute('SELECT * FROM salas WHERE nome = ?', (nome,))
        existing_sala = cursor.fetchone()

        if existing_sala:
            return jsonify({'success': False, 'error': 'Sala already exists'}), 400

        cursor.execute('INSERT INTO salas (nome, admin_id) VALUES (?, ?)', (nome, admin_id))
        db.commit()
        cursor.close()

        return jsonify({'success': True}), 200

    except Exception as e:
        print(e)
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

# atrelar uma sala a um computador
@app.route('/api/assign_sala', methods=['POST'])
def assign_sala():
    try:
        data = request.get_json()
        mac_address = data.get('mac_address')
        sala_id = data.get('sala_id')

        if not mac_address or not sala_id:
            return jsonify({'success': False, 'error': 'Falta o endereço MAC ou o ID da sala'}), 400

        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT * FROM computadores WHERE mac_address = ?', (mac_address,))
        computador = cursor.fetchone()

        if not computador:
            return jsonify({'success': False, 'error': 'Computador não encontrado'}), 404

        cursor.execute('SELECT * FROM salas WHERE id = ?', (sala_id,))
        sala = cursor.fetchone()

        if not sala:
            return jsonify({'success': False, 'error': 'Sala não encontrada'}), 404

        cursor.execute('UPDATE computadores SET sala_id = ? WHERE mac_address = ?', (sala_id, mac_address))
        db.commit()
        cursor.close()

        return jsonify({'success': True}), 200

    except Exception as e:
        print(e)
        return jsonify({'success': False, 'error': 'Internal server error'}), 500
    
# Rota para listar salas
@app.route('/api/salas', methods=['GET'])
def listar_salas():
    try:
        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT salas.id, salas.nome, administradores.username FROM salas LEFT JOIN administradores ON salas.admin_id = administradores.id')
        salas = cursor.fetchall()
        cursor.close()

        result = [{'id': sala[0], 'nome': sala[1], 'admin_username': sala[2]} for sala in salas]
        return jsonify(result), 200

    except Exception as e:
        print(e)
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

def bloquear_porta(ip, porta):
    try:
        errorIndication, errorStatus, errorIndex, varBinds = next(
            setCmd(SnmpEngine(),
                   CommunityData('private', mpModel=1),
                   UdpTransportTarget((ip, 161)),
                   ContextData(),
                   ObjectType(ObjectIdentity(f'1.3.6.1.2.1.2.2.1.7.{porta}'), Integer(2)))  # 2 significa "down"
        )

        if errorIndication:
            print(errorIndication)
            return False
        elif errorStatus:
            print('%s at %s' % (errorStatus.prettyPrint(),
                                errorIndex and varBinds[int(errorIndex) - 1][0] or '?'))
            return False
        else:
            return True
    except Exception as e:
        print(f"Erro ao bloquear porta: {e}")
        return False

def desbloquear_porta(ip, porta):
    try:
        errorIndication, errorStatus, errorIndex, varBinds = next(
            setCmd(SnmpEngine(),
                   CommunityData('private', mpModel=1),
                   UdpTransportTarget((ip, 161)),
                   ContextData(),
                   ObjectType(ObjectIdentity(f'1.3.6.1.2.1.2.2.1.7.{porta}'), Integer(1)))  # 1 significa "up"
        )

        if errorIndication:
            print(errorIndication)
            return False
        elif errorStatus:
            print('%s at %s' % (errorStatus.prettyPrint(),
                                errorIndex and varBinds[int(errorIndex) - 1][0] or '?'))
            return False
        else:
            return True
    except Exception as e:
        print(f"Erro ao desbloquear porta: {e}")
        return False

@app.route('/api/bloquear', methods=['POST'])
def bloquear():
    data = request.json
    ip = "10.90.90.90" 
    porta = data.get('porta')

    startDate = data.get('startDate')
    endDate = data.get('endDate')

    logging.info(f"Request to schedule block port: {porta} on IP: {ip} from {startDate} to {endDate}")

    db = get_db()
    cursor = db.cursor()
    cursor.execute('INSERT INTO port_blocks (port, startDate, endDate) VALUES (?, ?, ?)', 
                   (porta, startDate, endDate))
    db.commit()
    cursor.close()

    return jsonify({'success': True})

@app.route('/api/desbloquear', methods=['POST'])
def desbloquear():
    data = request.json
    ip = "10.90.90.90" 
    porta = data.get('porta')

    logging.info(f"Desbloqueando {porta}")

    desbloquear_porta(ip, porta)

    return jsonify({'success': True})

@app.route('/api/agendamentos', methods=['GET'])
def agendamentos():
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM port_blocks')
    bloqueios = cursor.fetchall()
    cursor.close()

    agendamentos = []
    for bloqueio in bloqueios:
        id, port, startDate, endDate = bloqueio
        agendamentos.append({
            'id': id,
            'port': port,
            'startDate': startDate,
            'endDate': endDate
        })

    return jsonify(agendamentos)

@app.route('/api/cancelar_agendamento', methods=['DELETE'])
def cancelar_agendamento():
    try:
        data = request.get_json()
        agendamento_id = data.get('id')

        if not agendamento_id:
            return jsonify({'success': False, 'error': 'Falta o ID'}), 400

        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT * FROM port_blocks WHERE id = ?', (agendamento_id,))
        agendamento = cursor.fetchone()

        if not agendamento:
            return jsonify({'success': False, 'error': 'Agendamento não encontrado'}), 404

        cursor.execute('DELETE FROM port_blocks WHERE id = ?', (agendamento_id,))
        db.commit()
        cursor.close()

        return jsonify({'success': True}), 200

    except Exception as e:
        print(e)
        return jsonify({'success': False, 'error': 'Internal server error'}), 500

def verificar_bloqueios():
    while True:
        db = get_db()
        cursor = db.cursor()
        cursor.execute('SELECT * FROM port_blocks')
        bloqueios = cursor.fetchall()

        for bloqueio in bloqueios:
            id, porta, startDate, endDate = bloqueio
            start_time = datetime.fromisoformat(startDate.replace('Z', '+00:00')).astimezone()
            end_time = datetime.fromisoformat(endDate.replace('Z', '+00:00')).astimezone()
            now = datetime.now(timezone.utc).astimezone()

            if start_time <= now <= end_time:
                logging.info(f"Blocking port {porta} on IP 10.90.90.90")
                bloquear_porta("10.90.90.90", porta)
            elif now > end_time:
                logging.info(f"Unblocking port {porta} on IP 10.90.90.90")
                desbloquear_porta("10.90.90.90", porta)
                cursor.execute('DELETE FROM port_blocks WHERE id = ?', (id,))
                db.commit()

        cursor.close()
        time.sleep(60)

if __name__ == '__main__':
    logging.info("Iniciando servidor...")
    init_db()
    threading.Thread(target=verificar_bloqueios, daemon=True).start()
    app.run(host='10.90.90.92', port=5000)
