import { useAuthStore } from "../store/authStore";

export function resetStores() {
  const stores = [useAuthStore];

  stores.forEach((store) => {
    store.setState(store.getInitialState());
  });
}
