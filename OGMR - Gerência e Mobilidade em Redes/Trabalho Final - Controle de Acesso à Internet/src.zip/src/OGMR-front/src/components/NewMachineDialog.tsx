import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

export function NewMachineDialog() {
  const form = useForm({
    defaultValues: {
      name: "",
      mac_address: "",
      ip: "",
    },
    criteriaMode: "all",
    delayError: 200,
    mode: "all",
  });

  const handleSend = async () => {
    try {
      const data = form.getValues();

      const response = await fetch("http://localhost:5000/api/machines", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const responseData = await response.json();

      if (responseData.success === true) {
        toast.success("Máquina adicionada com sucesso");
        form.reset();
      } else {
        console.error(responseData);
        toast.error("Não foi possível adicionar a máquina");
      }
    } catch (error) {
      toast.error("Erro inesperado ao adicionar a máquina");
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="default">{"Adicionar"}</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{"Acionar Máquina"}</DialogTitle>
          <DialogDescription>
            {"Adicione uma nova máquina ao sistema"}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              {"Nome"}
            </Label>
            <Input
              {...form.register("name")}
              id="name"
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="username" className="text-right">
              {"Endereço MAC"}
            </Label>
            <Input
              {...form.register("mac_address")}
              id="mac_address"
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="username" className="text-right">
              {"IP"}
            </Label>
            <Input {...form.register("ip")} id="ip" className="col-span-3" />
          </div>
        </div>
        <DialogFooter>
          <Button
            type="submit"
            onClick={form.handleSubmit(handleSend)}
            onSubmit={form.handleSubmit(handleSend)}
          >
            {"Save changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
