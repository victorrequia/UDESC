import { useState } from 'react';
import { BASE_URL } from "@/constants/config";
import "react-datepicker/dist/react-datepicker.css";
import { toast } from "sonner";
import { BlockDialog } from './BlockDialog';
import { Button } from './ui/button';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from './ui/dialog';

const DISABLED_PORTS = [24, 22, 21]; // Array com as portas que devem ser desabilitadas

const GridComponent = ({ data }: { data: any }) => {
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedSala, setSelectedSala] = useState('');

  const handleOpenDialog = (sala: string) => {
    setSelectedSala(sala);
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedSala('');
  };

  const handleConfirmBlock = () => {
    handleBlockAllInSala(selectedSala);
    handleCloseDialog();
  };

  const handleUnblock = async (port: string) => {
    try {
      const response = await fetch(`${BASE_URL}/api/desbloquear`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          porta: port,
        }),
      });

      const responseData = await response.json();

      if (responseData.success === true) {
        toast.success("OK!");
        window.location.reload();
      } else {
        console.error(responseData);
        toast.error("Erro!");
      }
    } catch (error) {
      console.error(error);
      toast.error("Erro inesperado ao agendar o bloqueio da máquina");
    }
  };

  const handleBlockAllInSala = async (sala: string) => {
    console.log('handleBlockAllInSala');

    const portsToBlock = data.filter((item: any) => item.sala === sala && !DISABLED_PORTS.includes(Number(item.port)));
    const startDate = new Date().toISOString();
    const endDate = new Date(Date.now() + 3600 * 1000).toISOString();

    try {
      const requests = portsToBlock.map((item: any) =>
        fetch(`${BASE_URL}/api/bloquear`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            porta: item.port,
            startDate: startDate,
            endDate: endDate,
          }),
        })
      );

      const responses = await Promise.all(requests);

      let success = true;
      for (const response of responses) {
        const responseData = await response.json();
        console.log('res =', responseData);
        if (responseData.success !== true) {
          success = false;
          console.error(responseData);
        }
      }

      if (success) {
        toast.success("Todas as portas foram bloqueadas com sucesso!");
        // window.location.reload();
      } else {
        toast.error("Erro ao bloquear algumas portas!");
      }
    } catch (error) {
      console.error(error);
      toast.error("Erro inesperado ao bloquear as portas");
    }
  };

  const groupBySala = (data: any[]) => {
    return data.reduce((acc, item) => {
      const sala = item.sala || 'Sem Sala';
      if (!acc[sala]) {
        acc[sala] = [];
      }
      acc[sala].push(item);
      return acc;
    }, {} as Record<string, any[]>);
  };

  const groupedData = groupBySala(data);

  return (
    <div className="p-4">
      {Object.entries(groupedData).map(([sala, items], index) => (
        <div key={index} className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">{sala}</h2>
            {sala !== 'Sem Sala' && (
              <>
                {/* <Button variant={'link'} onClick={() => handleOpenDialog(sala)}>
                  {'Bloquear todas as portas'}
                </Button> */}
                <Dialog open={openDialog} onOpenChange={setOpenDialog}>
                  <DialogTrigger asChild>
                    <Button variant="link" onClick={() => handleOpenDialog(sala)}>
                      {'Bloquear todas as portas'}
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Confirmação de Bloqueio</DialogTitle>
                      <DialogDescription>
                        Você tem certeza que deseja bloquear todas as portas na sala {selectedSala}?
                      </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                      <Button onClick={handleCloseDialog} variant="secondary">
                        Cancelar
                      </Button>
                      <Button onClick={handleConfirmBlock} variant="default">
                        Confirmar
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </>
            )}
          </div>
          <div className="grid grid-cols-4 gap-4">
            {items.map((item: any, index: any) => {
              const { mac_address, port, status } = item;
              const isDisabled = DISABLED_PORTS.includes(Number(port));

              return (
                <div
                  key={index}
                  className={`flex flex-col items-center justify-center p-4 border rounded transition-colors duration-300 ${
                    isDisabled ? 'bg-gray-400' : status === 'up' ? 'bg-green-500 hover:bg-green-600' : 'bg-red-500'
                  }`}
                >
                  <div className="flex flex-col items-center">
                    <h1 className="text-white text-xl">{`Máquina ${port}`}</h1>
                    {status === 'up' && !isDisabled && mac_address !== 'None' && (
                      <p className="text-white">{`MAC: ${mac_address}`}</p>
                    )}
                    {!isDisabled ? (
                      <div>
                        {status === 'up' && <BlockDialog disabled={status !== 'up'} porta={port} />}
                        {status === 'down' && (
                          <Button variant={'link'} onClick={() => handleUnblock(port)}>
                            {'Desbloquear'}
                          </Button>
                        )}
                      </div>
                    ) : (
                      <p className="text-white">Acesso Desabilitado</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
};

export default GridComponent;
