import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { BASE_URL } from "@/constants/config";
import { useQueryClient } from "@tanstack/react-query";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useForm } from "react-hook-form";
import { toast } from "sonner";


interface Props {
  disabled?: boolean,
  porta: string,
}

export function BlockDialog(props: Props) {

  const form = useForm({
    defaultValues: {
      startDate: new Date(),
      endDate: new Date()
    },
    criteriaMode: "all",
    delayError: 200,
    mode: "all",
  });

  const adjustToTimezone = (date: Date, timeZone: string) => {
    const invDate = new Date(date.toLocaleString('en-US', {
      timeZone: timeZone
    }));
    const diff = date.getTime() - invDate.getTime();
    return new Date(date.getTime() + diff);
  };

  const handleSend = async () => {
    try {
      const data = form.getValues();

      const startDate = adjustToTimezone(data.startDate, "America/Sao_Paulo").toISOString();
      const endDate = adjustToTimezone(data.endDate, "America/Sao_Paulo").toISOString();

  
      const response = await fetch(`${BASE_URL}/api/bloquear`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          porta: props.porta,
          startDate: startDate,
          endDate: endDate,
        }),
      });

      const responseData = await response.json();

      if (responseData.success === true) {
        toast.success("Bloqueio agendado com sucesso");
        form.reset();
      } else {
        console.error(responseData);
        toast.error("Não foi possível agendar o bloqueio da máquina");
      }
    } catch (error) {
      console.error(error);
      toast.error("Erro inesperado ao agendar o bloqueio da máquina");
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button disabled={props.disabled} variant="link">{"Agendar Bloqueio"}</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{"Bloquear Máquina"}</DialogTitle>
          <DialogDescription>
            {"Selecione a data e horário de início e fim do bloqueio"}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="startDate" className="text-right">
              {"Data e Horário Inicial"}
            </Label>
            <DatePicker
              selected={form.watch("startDate")}
              onChange={(date) => form.setValue("startDate", date)}
              showTimeSelect
              timeFormat="HH:mm"
              timeIntervals={1}
              dateFormat="Pp"
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="endDate" className="text-right">
              {"Data e Horário Final"}
            </Label>
            <DatePicker
              selected={form.watch("endDate")}
              onChange={(date) => form.setValue("endDate", date)}
              showTimeSelect
              timeFormat="HH:mm"
              timeIntervals={1}
              dateFormat="Pp"
              className="col-span-3"
            />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button" variant="secondary" onClick={form.handleSubmit(handleSend)}>
              {'Bloquear'}
            </Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
