import { AppLayout } from "@/pages/app/layout";
import { BaseLayout } from "@/pages/layout";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { DashboardScreen } from "./pages/app";
import { AuthLayout } from "./pages/auth/layout";
import { LoginScreen } from "./pages/auth/login";
import { MachinesScreen } from "@/pages/app/machines";
import { CalendarScreen } from "./pages/app/calendar";
import { RoomsScreen } from "./pages/app/rooms";
import { AdminsScreen } from "./pages/app/admins";

export function Router() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<BaseLayout />}>
          <Route path="/" element={<AppLayout />}>
            <Route index path="dashboard" element={<DashboardScreen />} />
            <Route path="machines" element={<MachinesScreen />} />
            <Route path="calendar" element={<CalendarScreen />} />
            <Route path="rooms" element={<RoomsScreen />} />
            <Route path="admins" element={<AdminsScreen />} />
          </Route>
          <Route path="/auth" element={<AuthLayout />}>
            <Route index path="login" element={<LoginScreen />} />
            {/* <Route path="register" element={<RegisterScreen />} /> */}
          </Route>
        </Route>
        <Route
          path="*"
          element={
            <div>
              <p>{"404"}</p>
            </div>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
