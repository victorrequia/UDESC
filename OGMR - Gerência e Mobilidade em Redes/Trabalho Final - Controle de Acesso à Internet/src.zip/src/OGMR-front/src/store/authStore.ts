import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

interface State {
  isLoggedIn: boolean;
  user: any;
}

interface Actions {
  setIsLoggedIn: (isLoggedIn: boolean) => void;
  setUser: (user: any) => void;
}

type Store = State & Actions & { reset: () => void };

const initialState: State = {
  isLoggedIn: false,
  user: undefined,
};

export const useAuthStore = create<Store>()(
  persist(
    (set) => ({
      ...initialState,
      setIsLoggedIn: (isLoggedIn: boolean) => {
        set({ isLoggedIn });
      },
      setUser: (user: any) => {
        set({ user });
      },
      reset: () => {
        set(initialState);
      },
    }),
    {
      name: "auth",
      storage: createJSONStorage(() => sessionStorage),
      // partialize: store => ({
      //   state: store.state,
      // }),
    }
  )
);
