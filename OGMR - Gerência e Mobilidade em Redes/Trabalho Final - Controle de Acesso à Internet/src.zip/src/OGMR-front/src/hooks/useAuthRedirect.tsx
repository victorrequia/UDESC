import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuthStore } from "../store/authStore";

export const useAuthRedirect = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const isLoggedIn = useAuthStore.getState().isLoggedIn;

    if (location.pathname.startsWith("/auth") === true && isLoggedIn === true) {
      navigate("/", { replace: true });
    } else if (
      location.pathname.startsWith("/auth") === false &&
      isLoggedIn === false
    ) {
      navigate("/auth/login", { replace: true });
    }
  }, [location.pathname]);
};
