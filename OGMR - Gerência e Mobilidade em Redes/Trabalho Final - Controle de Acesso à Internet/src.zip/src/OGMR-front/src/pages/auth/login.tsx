import { useForm } from "react-hook-form";
import { useAuthStore } from "../../store/authStore";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { BASE_URL } from "@/constants/config";

export function LoginScreen() {
  const navigate = useNavigate();

  const { setIsLoggedIn } = useAuthStore();

  const form = useForm({
    defaultValues: {
      username: "",
      password: "",
    },
    criteriaMode: "all",
    delayError: 200,
    mode: "all",
  });

  const handleLogin = async () => {
    try {
      const { username, password } = form.getValues();

      if (!username || !password) {
        toast.error("username and password are required");
        return;
      }

      const response = await fetch(`${BASE_URL}/api/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: username,
          password: password,
        }),
      });

      const data = await response.json();

      if (data.success === true) {
        setIsLoggedIn(true);
        navigate("/dashboard");
      } else {
        toast.error("Não foi possível fazer login");
      }
    } catch (error) {
      console.error(error)
      toast.error("Erro inesperado ao fazer login");
    }
  };

  return (
    <div>
      <div className="flex flex-col mb-4 items-center">
        <form
          onSubmit={form.handleSubmit(handleLogin)}
          className="flex flex-col"
        >
          <h1 className="text-2xl font-bold mb-4">{"Entrar no Sistema"}</h1>
          <label htmlFor="username">{"username"}</label>
          <input
            {...form.register("username")}
            // type="username"
            placeholder="Username"
            className="mb-4 rounded-md border border-gray-300 p-2"
          />
          <label htmlFor="password">{"Senha"}</label>
          <input
            {...form.register("password")}
            type="password"
            placeholder="Password"
            className="mb-4 rounded-md border border-gray-300 p-2"
          />
        </form>
        <button
          onClick={handleLogin}
          className="bg-blue-500 text-white hover:bg-blue-700 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
        >
          {"Entrar"}
        </button>
      </div>
    </div>
  );
}
