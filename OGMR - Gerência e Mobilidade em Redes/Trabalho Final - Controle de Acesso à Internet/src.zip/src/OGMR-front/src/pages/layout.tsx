import { useAuthRedirect } from "@/hooks/useAuthRedirect";
import { Outlet } from "react-router-dom";
import { Toaster } from "sonner";

export function BaseLayout() {
  useAuthRedirect();

  return (
    <div>
      <Outlet />
      <Toaster richColors expand position="bottom-right" />
    </div>
  );
}
