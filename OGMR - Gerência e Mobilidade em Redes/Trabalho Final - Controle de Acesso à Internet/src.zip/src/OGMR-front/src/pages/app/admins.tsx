import GridComponent from "@/components/GridComponent";
import { BASE_URL } from "@/constants/config";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

async function fetchAdmins() {
  try {
    const response = await fetch(`${BASE_URL}/api/administradores`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await response.json();

    return data;
  } catch (error) {
    toast.error("Erro inesperado ao buscar os administradores");
  }
}

export function AdminsScreen() {
  const { isLoading, data } = useQuery({
    queryKey: ['admins'],
    queryFn: () => fetchAdmins()
  });

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md py-4 px-6">
        <div>
          <p className="text-black font-bold text-2xl">
            Lista de Administradores
          </p>
          <p className="text-gray-600">
            Estes são os administradores
          </p>
        </div>
      </nav>
      <div className="p-6">
        {isLoading ? (
          <div className="flex justify-center items-center">
            <p className="text-gray-600">Carregando...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.map((admin: any) => (
              <div key={admin.id} className="bg-white shadow-md rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-800">
                  {admin.username}
                </h3>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
