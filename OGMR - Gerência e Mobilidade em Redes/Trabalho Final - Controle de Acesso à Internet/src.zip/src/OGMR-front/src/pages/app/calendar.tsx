import { Button } from "@/components/ui/button";
import { BASE_URL } from "@/constants/config";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export function CalendarScreen() {
  const [schedules, setSchedules] = useState<any[]>([]);
  const [isLoadingSchedules, setIsLoadingSchedules] = useState(true);

  useEffect(() => {
    fetchSchedules();
  }, []);

  async function fetchSchedules() {
    try {
      const response = await fetch(`${BASE_URL}/api/agendamentos`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();
      setSchedules(data);
      setIsLoadingSchedules(false);
    } catch (error) {
      toast.error("Erro inesperado ao buscar os agendamentos");
    }
  }

  async function cancelSchedule(id: number) {
    try {
      const response = await fetch(`${BASE_URL}/api/cancelar_agendamento`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id }),  // Passa o id no corpo da requisição
      });

      if (response.ok) {
        toast.success("Agendamento cancelado com sucesso");
        fetchSchedules();
      } else {
        const errorData = await response.json();
        toast.error(`Erro ao cancelar o agendamento: ${errorData.error}`);
      }
    } catch (error) {
      toast.error("Erro inesperado ao cancelar o agendamento");
    }
  }

  return (
    <div>
      <div>
        <nav className="flex justify-between items-center p-4">
          <div>
            <p className="text-black font-bold text-xl">{"Calendário"}</p>
            <p className="text-black">{"Estas são as máquinas agendadas para bloqueio/desbloqueio"}</p>
          </div>
        </nav>
        <div className="m-4 border border-gray-200 rounded-md">
          {isLoadingSchedules === false ? (
            <div>
              {schedules.map((schedule, index) => (
                <div key={index} className="p-4 border-b border-gray-200 flex justify-between items-center">
                  <div>
                    <p><strong>Porta:</strong> {schedule.port}</p>
                    <p><strong>Início:</strong> {new Date(schedule.startDate).toLocaleString()}</p>
                    <p><strong>Fim:</strong> {new Date(schedule.endDate).toLocaleString()}</p>
                  </div>
                  <Button onClick={() => cancelSchedule(schedule.id)} className="bg-red-500 text-white">
                    Cancelar
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div><p>carregando</p></div>
          )}
        </div>
      </div>
    </div>
  );
}
