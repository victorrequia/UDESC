import GridComponent from "@/components/GridComponent";
import { BASE_URL } from "@/constants/config";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

async function fetchMachines() {
  try {
    const response = await fetch(`${BASE_URL}/api/computadores`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    const data = await response.json();
 
    return data;
  } catch (error) {
    toast.error("Erro inesperado ao buscar as máquinas");
  }
}

export function MachinesScreen() {

  const { isLoading, data } = useQuery({
    queryKey: ['machines'],
    queryFn:  () => fetchMachines()
  })
  
  return (
    <div>
      <div>
        <nav className="flex justify-between items-center p-4">
        <div>
            <p className="text-black font-bold text-xl">
              {"Lista de Máquinas"}
            </p>
            <p className="text-black">
              {"Estas são as máquinas que estão conectadas no switch"}
            </p>
          </div>
        </nav>
        <div className="m-4 border border-gray-200 rounded-md">
            {isLoading === false ? 
              data ? <GridComponent data={data} />  : <p>sem dados</p>
              : 
              <div><p>Carregando...</p></div> 
            }
        </div>
      </div>
    </div>
  );
}
