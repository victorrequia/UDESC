
export function DashboardScreen() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-semibold mb-4">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <div className="bg-white shadow-md rounded-lg p-4">
          <h2 className="text-xl font-bold">Máquinas Ativas</h2>
          <p className="text-2xl mt-2">34</p>
        </div>
        <div className="bg-white shadow-md rounded-lg p-4">
          <h2 className="text-xl font-bold">Eventos Recentes</h2>
          <p className="text-2xl mt-2">12</p>
        </div>
        <div className="bg-white shadow-md rounded-lg p-4">
          <h2 className="text-xl font-bold">Admins Online</h2>
          <p className="text-2xl mt-2">5</p>
        </div>
        <div className="bg-white shadow-md rounded-lg p-4">
          <h2 className="text-xl font-bold">Salas Disponíveis</h2>
          <p className="text-2xl mt-2">8</p>
        </div>
      </div>
      <div className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-bold mb-4">Resumo das Atividades</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                <th className="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome</th>
                <th className="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Última Atualização</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <tr>
                <td className="py-4 px-6 whitespace-nowrap">1</td>
                <td className="py-4 px-6 whitespace-nowrap">Máquina A</td>
                <td className="py-4 px-6 whitespace-nowrap">Ativa</td>
                <td className="py-4 px-6 whitespace-nowrap">2024-06-27</td>
              </tr>
              <tr>
                <td className="py-4 px-6 whitespace-nowrap">2</td>
                <td className="py-4 px-6 whitespace-nowrap">Máquina B</td>
                <td className="py-4 px-6 whitespace-nowrap">Inativa</td>
                <td className="py-4 px-6 whitespace-nowrap">2024-06-26</td>
              </tr>
              <tr>
                <td className="py-4 px-6 whitespace-nowrap">3</td>
                <td className="py-4 px-6 whitespace-nowrap">Máquina C</td>
                <td className="py-4 px-6 whitespace-nowrap">Inativa</td>
                <td className="py-4 px-6 whitespace-nowrap">2024-06-25</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
