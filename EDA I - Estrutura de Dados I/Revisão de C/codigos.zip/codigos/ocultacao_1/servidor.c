#include "interface.h"

/* MODELO DE DADOS */
typedef struct data{	char msg[60];
			int numPalavras;
			int tam;
		}Data;

Data*  cria(void)
{  
	int contaChar=0, contaPalavra=0;
    	char *token;
	char frase[]="This is www.tutorialspoint.com website";
	Data *aux=NULL;
	
	printf("\n %s ","\U0001F4E2 ");
	
	aux= (Data*)malloc(sizeof(Data));
	if (aux)
	{
		strcpy(aux->msg,frase);
				   
	   	/* get the tokens */
	   	token = strtok(frase, " ");
	   	while( token != NULL ) {
			contaPalavra++;	
			contaChar += strlen(token);
	      		token = strtok(NULL, " ");
	   	}
		aux->numPalavras=contaPalavra;
		aux->tam=contaChar;

	}
	return aux;
}

Data * liberaDaMem(Data *p)
{  	free(p);
	printf("\n %s Garbage Collection \n\n","\U0001F9FD ");
	return NULL;
}

void exibe(Data *aux)
{			
	printf(" \"%s\":  \n %s %i palavras no total de %i caracteres.",aux->msg, "\U0001F4E2 ",aux->numPalavras, aux->tam);
}




   
