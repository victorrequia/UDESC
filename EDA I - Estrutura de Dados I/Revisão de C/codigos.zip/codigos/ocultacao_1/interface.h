#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* OCULTAÇÃO DOS DETALHES DO MODELO DE DADOS
 POR MEIO DE UMA ESPECIFICAÇÃO PARCIAL */
typedef struct data Data;


/* PROTÓTIOPS DAS OPERAÇÕES SOBRE O MODELO DE DADOS */
Data* cria(void);
Data *liberaDaMem(Data *p);
void exibe(Data*aux);
