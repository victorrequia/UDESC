#include "interface.h"

// gcc -o saida -Wall *.c -lm

int main(void)
{	Data *p = NULL;
	system("clear");
	printf("\n\n");	
	p = cria();
	if(p)
	{	exibe(p);
		
	// descomente a linha seguinte para avaliar a ocultação
	// do modelo de dados do módulo servidor
	//	printf(" \"%s\": %i palavras no total de %i caracteres.",p->msg, p->numPalavras, p->tam);
		
		printf("\n\n TECLE");
		getchar();
		liberaDaMem(p);
	}

	
}	
	
		
