#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* OCULTAÇÃO DOS DETALHES DO MODELO DE DADOS
 POR MEIO DE UMA ESPECIFICAÇÃO PARCIAL */
typedef struct nodo Nodo;

/* PROTÓTIOPS DAS OPERAÇÕES SOBRE O MODELO DE DADOS */
Nodo * criaSeqFib(int n);
void exibeSeqFib(Nodo * lista);
Nodo * deletaSeqFib(Nodo * lista);
