#include "interface.h"

// Comente a linha abaixo para obter implementaçao duplamente encadeada
#define SIMP_ENCADEADA 



#ifdef SIMP_ENCADEADA 


//////////////////////////
//------ IMPLEMENTACAO SIMPLESMENTE ENCADEADA //////////////////////////
//////////////////////////

/* MODELO DE DADOS */
typedef struct nodo{	int fib;
						struct nodo *link;
		}Nodo;

Nodo * criaSeqFib(int n)
{   
	Nodo *aux1 = NULL, *aux2 = NULL, *lista=NULL; 
    int a=0, b = 1, i, auxiliar;	
   
    printf("\n\n IMPLEMENTACAO SIMPLESMENTE ENCADEADA \n\n");
   	printf("\n TECLE \n");
	getchar();
   	for(i=0;i<n;i++)
		{	//printf("\n %i \n",i);
			auxiliar = a + b;
			a = b;
			b = auxiliar;
 
			// Imprimo o número na tela.
			//printf("%d\n", auxiliar);
				
			aux2 = (Nodo *) malloc(sizeof(Nodo));
			if(aux2 == NULL)	
			{
				fprintf(stderr, "Erro na alocaçao de memoria! Exiting...\n");
				exit(-1);
			}
			if(i== 0) 
			{	aux1=lista=aux2;
				lista->fib = auxiliar;
				lista->link=NULL;
			}				
			aux1->link=aux2;
			aux2->fib = auxiliar;
			aux2->link=NULL;
			aux1=aux2;
		}	
	return lista;
}

void exibeSeqFib(Nodo * lista)
{	Nodo *aux1 = NULL; 			

	aux1=lista;	
	while(aux1 != NULL)
	{	printf("\n fib: %i \n", aux1->fib);
		aux1=aux1->link;
	}
}


Nodo * deletaSeqFib(Nodo * lista)
{	Nodo *aux1 = NULL; 	
	
	// Muito importante: um free() para cada malloc()!!!!!!!!!
	aux1=lista;
	while(lista->link != NULL)
	{	lista=lista->link;	
		printf("\n Removendo %i \n", aux1->fib);
		free(aux1);
		aux1=lista;
	}	
	printf("\n Removendo %i \n", aux1->fib);
	free(aux1);
	return NULL;
}

#else 


//////////////////////////
//------ IMPLEMENTACAO DUPLAMENTE ENCADEADA  //////////////////////////
//////////////////////////

/* MODELO DE DADOS */
typedef struct nodo{	int fib;
						struct nodo *dir;
						struct nodo *esq;
		}Nodo;

Nodo * criaSeqFib(int n)
{
	Nodo *aux1 = NULL, *aux2 = NULL, *lista=NULL; 
    int a=0, b = 1, i, auxiliar;	
    
    printf("\n\n IMPLEMENTACAO DUPLAMENTE ENCADEADA \n\n");
    printf("\n TECLE \n");
	getchar();
   	for(i=0;i<n;i++)
		{	//printf("\n %i \n",i);
			auxiliar = a + b;
			a = b;
			b = auxiliar;
 
			// Imprimo o número na tela.
			//printf("%d\n", auxiliar);
				
			aux2 = (Nodo *) malloc(sizeof(Nodo));
			if(aux2 == NULL)	
			{
				fprintf(stderr, "Erro na alocaçao de memoria! Exiting...\n");
				exit(-1);
			}
			if(i== 0) 
			{	aux1=lista=aux2;
				lista->fib = auxiliar;
				lista->dir=NULL;
				lista->esq=NULL;
			}				
			aux1->dir=aux2;
			aux2->fib = auxiliar;
			aux2->esq=aux1;
			aux2->dir=NULL;
			aux1=aux2;
		}	
	return lista;
}

void exibeSeqFib(Nodo * lista)
{	Nodo *aux1 = NULL; 			

	aux1=lista;	
	while(aux1 != NULL)
	{	printf("\n fib: %i \n", aux1->fib);
		aux1=aux1->dir;
	}
}


Nodo * deletaSeqFib(Nodo * lista)
{	Nodo *aux1 = NULL; 	
	
	// Muito importante: um free() para cada malloc()!!!!!!!!!
	aux1=lista;
	while(lista->dir != NULL)
	{	lista=lista->dir;	
		printf("\n Removendo %i \n", aux1->fib);
		free(aux1);
		aux1=lista;
	}	
	printf("\n Removendo %i \n", aux1->fib);
	free(aux1);
	return NULL;
}



#endif

