#include "interface.h"

// gcc -o saida -Wall *.c -lm


int main(void)
{	Nodo *seqFib=NULL;
	int n = 10;
	system("clear");
	seqFib = criaSeqFib(n);
	
	// descomente a linha seguinte para avaliar a ocultação
	// do modelo de dados do módulo servidor
	//printf(" %i",seqFib->fib);
	
	printf("\n------------ Sequencia de Fibonnaci pra n = %i ----------------\n", n);		
	exibeSeqFib(seqFib);
	
	printf("\n TECLE \n");
	getchar();
	
	printf("\n------------ Garbage Collection... ----------------\n");
	seqFib= deletaSeqFib(seqFib);

	printf("\n\n");
}	
	
		
