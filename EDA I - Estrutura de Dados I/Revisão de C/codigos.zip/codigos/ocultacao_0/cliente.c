#include "interface.h"

struct xyz{	char naipe[30];
		char sf0[30];
		char sf1[30];
		char sf2[30];
		char sf3[30];
		char sf4[30];
	};

// gcc -o saida -Wall *.c -lm

int main(void)
{
	struct xyz www={"Copas","\U0001F0BA ","\U0001F0BB ", "\U0001F0BD ","\U0001F0BE ","\U0001F0B1"};
	system("clear");
	printf("\n Royal Flush:\n");	
	printf("\n %s %s %s %s %s \n\n", www.sf0, www.sf1,www.sf2, www.sf3,www.sf4);
	func();
	
}	
	
		
