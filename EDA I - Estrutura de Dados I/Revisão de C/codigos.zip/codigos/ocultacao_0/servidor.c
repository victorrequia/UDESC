#include "interface.h"



void  func(void)
{  	//struct xyz ttt={"Ouros","\U0001F0CA ","\U0001F0CB ", "\U0001F0CD ","\U0001F0CE ","\U0001F0C1"};
 	//printf("\n %s %s %s %s %s \n\n", ttt.sf0, ttt.sf1, ttt.sf2, ttt.sf3, ttt.sf4);
	printf("\n %s \n","\U0001F6A9 ");	
	return;
}






   
