#include "arq_interface.h"


//======================METODOS PRIVATIVOS DA ABB=====================

void percorreEmPreOrdem(NoABB *pa);
void percorreEmPosOrdem(NoABB *pa);
void percorreEmOrdem(NoABB *pa);

